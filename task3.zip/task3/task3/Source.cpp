#include <iostream>
#include <string>

using namespace std;

class LiquidityPool {
private:
    string tokenX, tokenY;
    double amountX, amountY, k;

public:
    LiquidityPool(string tx, string ty, double ax, double ay)
        : tokenX(tx), tokenY(ty), amountX(ax), amountY(ay) {
        // Initialize k as the product of the initial amounts of the two tokens
        k = amountX * amountY;
    }

    void getPoolStatus() {
        // Display the current status of the pool
        cout << "Pool Status:\n";
        cout << tokenX << ": " << amountX << "\n";
        cout << tokenY << ": " << amountY << "\n";
        cout << "k: " << k << "\n";
    }

    void swapTokens(string token, double amount) {
        // Check if the token to swap is tokenX
        if (token == tokenX) {
            // Calculate the new amount of tokenX after the swap
            double newAmountX = amountX - amount;
            // Calculate the new amount of tokenY to keep the product k constant
            double newAmountY = k / newAmountX;
            // Calculate the amount of tokenY received
            double amountY = newAmountY - amountY;
            // Update the pool amounts
            amountX = newAmountX;
            amountY = newAmountY;
            // Display the swap details
            cout << "Swapped " << amount << " " << tokenX << " for " << amountY << " " << tokenY << "\n";
        }
        // Check if the token to swap is tokenY
        else if (token == tokenY) {
            // Calculate the new amount of tokenY after the swap
            double newAmountY = amountY - amount;
            // Calculate the new amount of tokenX to keep the product k constant
            double newAmountX = k / newAmountY;
            // Calculate the amount of tokenX received
            double amountX = newAmountX - amountX;
            // Update the pool amounts
            amountY = newAmountY;
            amountX = newAmountX;
            // Display the swap details
            cout << "Swapped " << amount << " " << tokenY << " for " << amountX << " " << tokenX << "\n";
        }
        else {
            // Handle invalid token input
            cout << "Invalid token\n";
        }
    }
};

int main() {
    string tokenX, tokenY;
    double amountX, amountY;

    // Welcome message and prompt for initial token details
    cout << "Welcome to the v2 Liquidity Pool CLI\n";
    cout << "Enter the name of token X: ";
    cin >> tokenX;
    cout << "Enter the name of token Y: ";
    cin >> tokenY;
    cout << "Enter the initial amount of " << tokenX << ": ";
    cin >> amountX;
    cout << "Enter the initial amount of " << tokenY << ": ";
    cin >> amountY;

    // Create a new LiquidityPool instance
    LiquidityPool pool(tokenX, tokenY, amountX, amountY);

    while (true) {
        // Display menu options
        cout << "\nOptions:\n";
        cout << "1. View Pool Status\n";
        cout << "2. Swap Tokens\n";
        cout << "3. Exit\n";
        cout << "Select an option: ";
        int choice;
        cin >> choice;

        // Handle menu options
        if (choice == 1) {
            pool.getPoolStatus();
        }
        else if (choice == 2) {
            string swapToken;
            double swapAmount;
            // Prompt for swap details
            cout << "Enter the token to swap (" << tokenX << "/" << tokenY << "): ";
            cin >> swapToken;
            cout << "Enter the amount of " << swapToken << " to swap: ";
            cin >> swapAmount;
            // Perform the token swap
            pool.swapTokens(swapToken, swapAmount);
        }
        else if (choice == 3) {
            cout << "Exiting...\n";
            break;
        }
        else {
            cout << "Invalid option. Please try again.\n";
        }
    }

    return 0;
}
